const mongoose = require('mongoose');

mongoose.connect("mongodb://127.0.0.1/mongodb", {useNewUrlParser:true});

mongoose.connection
    .once('open', () => console.log('connected'))
    .on('error', () => {
        console.log("Your Errored");
    });