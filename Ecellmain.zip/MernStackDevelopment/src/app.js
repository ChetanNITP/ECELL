const express = require("express")();
const path = require("path");
const app = express;
const hbs = require("hbs");

require("./db/conn.js");

const port = process.env.port || 3000;


app.get("/", function(req, res){

    res.sendFile(path.join(__dirname,'../public'));
});

const template_path = path.join(__dirname, "../templates/views");


app.set("view engine", "hbs");
app.set("views", template_path);
//hbs.registerPartials(path.join(__dirname, "../templates/patials"));

app.get("/", (req, res) => {
    res.render("index")
});

app.listen(port, () => {
    console.log('server is running at port no ' + port);
});

